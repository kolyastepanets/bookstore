$('.coping_billing_address').click().hide();
